***** What will we practice? *****

1. Sorting
1.1. Interchange sort/ Bubble sort
1.2. Selection sort 
1.3. Insertion sort
1.4. Quick sort
1.5. Merge sort

***** What exercises will we do? *****
Practice 1, 2, 3, 4, 5, 6

*********************************** 
If you have any question, please contact me:
Email: maithaiquoc@gmail.com

Thank you.
